<?php
// Incluir el archivo de conexión a la base de datos
include('../connection.php');

// Verificar si el formulario fue enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capturar los datos del formulario
    $codigo_cliente = $_POST['codigo_cliente'];
    $nombre_cliente = $_POST['nombre_cliente'];
    $apellido1_cliente = $_POST['apellido1_cliente'];
    $apellido2_cliente = $_POST['apellido2_cliente'];
    $telefono_cliente = $_POST['telefono_cliente'];
    $codigo_region_cliente = $_POST['codigo_region_cliente'];

    // Validar que los campos no estén vacíos
    if (!empty($codigo_cliente) && !empty($nombre_cliente) && !empty($telefono_cliente) && !empty($codigo_region_cliente)) {
        // Consulta SQL para insertar el nuevo cliente
        $query = "INSERT INTO MMVK_CLIENTES (CODIGO_CLIENTE, NOMBRE_CLIENTE, APELLIDO1_CLIENTE, APELLIDO2_CLIENTE, TELEFONO_CLIENTE, CODIGO_REGION_CLIENTE) 
                  VALUES (:codigo_cliente, :nombre_cliente, :apellido1_cliente, :apellido2_cliente, :telefono_cliente, :codigo_region_cliente)";

        // Preparar la consulta
        $stid = oci_parse($conn, $query);

        // Vincular los parámetros
        oci_bind_by_name($stid, ':codigo_cliente', $codigo_cliente);
        oci_bind_by_name($stid, ':nombre_cliente', $nombre_cliente);
        oci_bind_by_name($stid, ':apellido1_cliente', $apellido1_cliente);
        oci_bind_by_name($stid, ':apellido2_cliente', $apellido2_cliente);
        oci_bind_by_name($stid, ':telefono_cliente', $telefono_cliente);
        oci_bind_by_name($stid, ':codigo_region_cliente', $codigo_region_cliente);

        // Ejecutar la consulta
        $result = oci_execute($stid);

        // Verificar si la inserción fue exitosa
        if ($result) {
            echo "<p>Cliente agregado exitosamente.</p>";
        } else {
            $error = oci_error($stid); // Obtener el error de la consulta
            echo "<p>Error al agregar cliente: " . $error['message'] . "</p>";
        }

        // Liberar el recurso de la consulta
        oci_free_statement($stid);
    } else {
        echo "<p>Por favor, complete todos los campos obligatorios.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Cliente</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f4f8;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 600px;
            text-align: center;
        }
        h1 {
            color: #4CAF50;
            margin-bottom: 20px;
        }
        label {
            font-size: 1.2em;
            margin: 10px 0;
            display: block;
            text-align: left;
        }
        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0 20px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1em;
        }
        button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            font-size: 1.2em;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #45a049;
        }
        .message {
            color: green;
            margin-top: 10px;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Agregar Nuevo Cliente</h1>
        <!-- Formulario para agregar cliente -->
        <form action="agregaclientes_ejemplo.php" method="POST">
            <label for="codigo_cliente">Código Cliente:</label>
            <input type="number" id="codigo_cliente" name="codigo_cliente" required><br>

            <label for="nombre_cliente">Nombre:</label>
            <input type="text" id="nombre_cliente" name="nombre_cliente" required><br>

            <label for="apellido1_cliente">Primer Apellido:</label>
            <input type="text" id="apellido1_cliente" name="apellido1_cliente" required><br>

            <label for="apellido2_cliente">Segundo Apellido:</label>
            <input type="text" id="apellido2_cliente" name="apellido2_cliente"><br>

            <label for="telefono_cliente">Teléfono:</label>
            <input type="number" id="telefono_cliente" name="telefono_cliente" required><br>

            <label for="codigo_region_cliente">Código de Región:</label>
            <input type="number" id="codigo_region_cliente" name="codigo_region_cliente" required><br>

            <button type="submit">Agregar Cliente</button>
        </form>
    </div>

</body>
</html>
