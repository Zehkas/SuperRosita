<?php 
include '../connection.php'; // Asegúrate de que este archivo establece la conexión sin cerrarla inmediatamente

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los datos del formulario
    $codigo = $_POST['codigo_pais'];
    $nombre = $_POST['nombre_pais'];

    // Verificar que los campos no estén vacíos
    if (empty($codigo) || empty($nombre)) {
        echo "Por favor, complete todos los campos.";
    } else {
        // Preparar la consulta SQL
        $sql = "INSERT INTO MMVK_PAIS_ORIGEN_PRODUCTO (CODIGO_PAIS_ORIGEN_PRODUCTO, NOMBRE_PAIS_ORIGEN_PRODUCTO) 
                VALUES (:codigo, :nombre)";

        // Preparar la sentencia
        $stmt = oci_parse($conn, $sql);

        // Asignar los valores a los placeholders
        oci_bind_by_name($stmt, ":codigo", $codigo);
        oci_bind_by_name($stmt, ":nombre", $nombre);

        // Ejecutar la consulta
        if (oci_execute($stmt)) {
            echo "<div style='text-align: center; color: green; font-size: 18px;'>Datos insertados correctamente.</div>";
        } else {
            $e = oci_error($stmt);
            echo "<div style='text-align: center; color: red; font-size: 18px;'>Error al insertar los datos: " . htmlentities($e['message']) . "</div>";
        }
    }
}

// Cerrar la conexión después de usarla
oci_close($conn);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar País de Origen</title>
    <style>
        /* Reset de márgenes y padding */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Estilos generales de la página */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #6a11cb, #2575fc); /* Fondo degradado */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        /* Contenedor del formulario */
        .form-container {
            background-color: #ffffff;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
        }

        /* Títulos */
        h1 {
            color: #333;
            font-size: 24px;
            margin-bottom: 20px;
        }

        /* Estilos de las etiquetas */
        label {
            display: block;
            margin-bottom: 10px;
            font-size: 16px;
            color: #555;
        }

        /* Estilos de los inputs */
        input[type="number"], input[type="text"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            color: #333;
        }

        /* Botón */
        button {
            width: 100%;
            padding: 10px;
            background-color: #2575fc;
            color: white;
            font-size: 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #6a11cb;
        }

        /* Mensajes de error o éxito */
        .message {
            font-size: 18px;
            margin-top: 10px;
        }

    </style>
</head>
<body>
    <div class="form-container">
        <h1>Agregar País de Origen</h1>
        <form method="post" action="agregardatosapais_origen_producto.php">
            <label for="codigo_pais">Código del País:</label>
            <input type="number" id="codigo_pais" name="codigo_pais" required><br>

            <label for="nombre_pais">Nombre del País:</label>
            <input type="text" id="nombre_pais" name="nombre_pais" required><br>

            <button type="submit">Agregar</button>
        </form>
    </div>
</body>
</html>
