<?php
include 'connection.php';

// Consulta para verificar si la tabla ya existe
$checkTable = "SELECT COUNT(*) AS TABLE_EXISTS FROM user_tables WHERE table_name = 'MMVK_PAIS_ORIGEN_PRODUCTO'";
$checkStmt = oci_parse($conn, $checkTable);
oci_execute($checkStmt);
$row = oci_fetch_array($checkStmt, OCI_ASSOC);

if ($row['TABLE_EXISTS'] == 0) {
    // La tabla no existe, entonces se crea
    $sql = "CREATE TABLE MMVK_PAIS_ORIGEN_PRODUCTO(
        CODIGO_PAIS_ORIGEN_PRODUCTO NUMBER,
        NOMBRE_PAIS_ORIGEN_PRODUCTO VARCHAR2(20),
        CONSTRAINT PK_MMVK_PAIS_ORIGEN_PRODUCTO PRIMARY KEY(CODIGO_PAIS_ORIGEN_PRODUCTO)
    )";

    $stmt = oci_parse($conn, $sql);

    if (oci_execute($stmt)) {
        echo "La tabla ha sido creada" . "<br>";
    } else {
        $e = oci_error($stmt);
        echo "No se ha podido crear la tabla: " . htmlentities($e['message']) . "<br>";
    }
} else {
    echo "La tabla ya existe. No se requiere crearla nuevamente.<br>";
}

// Cerrar la conexión
oci_close($conn);
?>
