<?php
    header('Location: vista/index.php');

?>