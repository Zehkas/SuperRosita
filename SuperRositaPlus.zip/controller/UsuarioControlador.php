<?php

require_once './model/usuario.php';

class UsuarioControlador {
    public function Registro() {
        // Lógica para el registro del usuario
    }

    public function Login() {
        // Lógica para el login del usuario
    }
}
?>
